
    $("#reserveModalToggle").click(function(){
    		$("#reserveModal").modal("toggle");

	});
		$("#loginModalToggle").click(function(){
    		$("#loginModal").modal("toggle");

	});
